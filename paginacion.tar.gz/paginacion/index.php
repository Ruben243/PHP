<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title>Listado de mujeres</title>
</head>
<body>
<?php
include 'config.php';
?>
<header>
  <h3 >Mostrar datos</h3>
   
</header>
<section>

<table id='tabla'>
    <tr class='celda'>
    <th class='celda'>Especie</th>
    <th class='celda'>Nombre</th>
    <th class='celda'>Altura</th>
    <th class='celda'>Periodo</th>

    </tr>
    <?php
     $filas=4;

     if(!isset($_GET["nPag"])) $nPag=0;else $nPag=$_GET["nPag"];

     $inicio=$nPag*$filas;

     if($rs=$cn->query("select * from dinosaurios limit $inicio,$filas "));
     
     $row_cnt = mysqli_num_rows($rs);
  
     while ($obj = $rs->fetch_object()) {  
        echo "<tr  class='celda'>";
        echo "<td  class='celda'>". $obj->especie."</td>";
        echo "<td  class='celda'>". $obj->nombre."</td>";
        echo "<td  class='celda'>".utf8_encode($obj->altura)."</td>";//utf_encode para las ñ
        echo "<td  class='celda'>". $obj->periodo."</td>";
        echo "</tr>";

     }
     

    echo "</tr>";
    echo "</table>";   
     ?>
     <br>
     <div>     <?php 
    if($rsC= $cn->query("select * from dinosaurios"));


    $row_cnt = mysqli_num_rows($rsC);
    $totalPag=floor($row_cnt/$filas);

    if(($row_cnt%$filas)>0)$totalPag++;

   
    ?>
   
    <?php
     echo "<div id='pagina'>Pagina Nº ".($nPag+1)." de ".$totalPag."</div>";
     echo "<br>";
    for ($i=0; $i <$totalPag ; $i++) { 
        if ($i==$nPag) {
            echo "<a href=''>".($i+1)."</a>";
        }else{
            ?>
            <a href=<?php echo $_SERVER['PHP_SELF']."?nPag=$i"?>>
            <?php echo ($i+1)  ?> </a>
    <?php

        }

    }

    
    ?>
   </div>
   
    
   
</section>

</body>
</html>
